
<?php include 'head.php'; ?>
<body>
<div class="container-fluid pad-fix">
<!--	Navbar     -->
<?php include 'nav.php'; ?>
<!--navbar ends-->
	<section class="sec-pad-top sec-pad-btm">
	<div class="container-fluid container-fluid2 cont_c">
		<div class="col-md-12">
			<h1 class="contact-h1">Contact Us</h1>
			<hr class="s6-hr">
		</div>
		<div class="col-lg-12 row pad_fix">
			<div class="col-lg-6">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14131.463547500414!2d85.30192247359004!3d27.69053966387876!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb184a281e7491%3A0x96a5dbfae4de26d!2sMidas+Technologies+Pvt.+LTd!5e0!3m2!1sen!2snp!4v1517115200960" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
		</div>
			<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 font-color-primary">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pad_fix">    
				<h4 class="contact-sub-title">MiDas Technologies Pvt. Ltd.</h4>
						<p class="contact-detail">
					 Sanepa Heights Rd, Lalitpur, Nepal.<br>
						<!-- Toll Free No: 1660 - 01 – 00000<br> -->
			Tel Ph. No: +977-01-5526279<br>
			info@midas.com.np<br>
			</p>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 row pad_fix">
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pad_lt_fix">
				<p class="contact-detail">
				<strong> <u>For Sales/General Enquiry</u></strong><br>
				bibek@midastechnologies.com.np<br>
				977-9851179194
				</p>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pad_lt_fix">
				<p class="contact-detail">
				<strong> <u>For Web Enquiry</u></strong><br>
				diwas@midastechnologies.com.np<br>
				977-9851233986
				</p>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="padding:0;">
			<strong>For Technical Support</strong>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  pad_fix">
			<p class="contact-detail">
						<strong> <u>For HMIS &amp; LIS</u></strong><br>
						amrit@midastechnologies.com.np<br>
						977-9851179196
					   <br>
						rajkumar@midastechnologies.com.np<br>
						977-9841716545
						</p>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 row pad_fix">
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pad_lt_fix">
					   <p class="contact-detail">
						<strong> <u>For SMIS &amp; SCIS</u></strong><br>
						abeesake1@gmail.com<br>
						977-9801052066
						</p>
					</div>
					  <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pad_lt_fix">       
							<p class="contact-detail">
							<strong> <u>For Pharmacy, Account &amp; PIS</u></strong><br>
							bibek@midastechnologies.com.np<br>
							977-9851179194
							</p>
					   </div>
			</div>
			</div>
		</div>
	</div>
	
	</section>

<?php include 'footer.php'; ?>
</div>
<?php include 'loadjs.php' ?>
</body>
</html>
