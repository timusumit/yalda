
<?php include 'head.php'; ?>
<body>
<div class="container-fluid pad-fix">
<!--	Navbar     -->
<?php include 'nav.php'; ?>
<!--navbar ends-->
<!--
	<div class="container-fluid top-fixed-inner" style="padding: 0px;width:100%;">
	</div>
-->
<!--	<div class="parallax-window" data-parallax="scroll" data-image-src="img/inner-banner.png"></div>-->
	<section class="inner-sec1 sec-pad-top in-sec-bg ">
		<div class="wrap-product-content">
			<div class="container-fluid container-fluid2">
				<div class="row">					
					<div class="col-lg-12 col-md-12 col-sm-12 colxs-12"><h3 class="whyus-tit">For <strong> Hospitals</strong></h3></div>
					<div class="col-md-3 pad-10-fix s2-marg-btm">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bg-box pad-10-fix text-center "><img src="img/products/hmis.jpg" class="img-rounded img-fluid">
							<h4 class="head-main-sub-intro">HMIS</h4>
							<hr class="s2-hr">
							 <p class="whyuspara text-justify"><strong>Hospital Management and Information System - HMIS</strong>, Collection, compilation, analysis and interpretation 
							 of data for effective use as information which helps in better planning, monitoring and control of medical and health services which also helps in improving of the efficiency and Performance of ... <br></p>
							<div class="readmore-pro"><a href="hmis-detail.php">Read More</a></div>

						</div>

						</div>
					<div class="col-md-3 pad-10-fix s2-marg-btm">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bg-box pad-10-fix text-center "><img src="img/products/lis.jpg" class="img-rounded img-fluid">
						 <h4 class="head-main-sub-intro">LIS</h4>
							<hr class="s2-hr">
						  <p class="whyuspara text-justify"><strong>Laboratory Information System - LIS</strong>, A software system that records, manages, and stores data for hospital laboratories.
						  A LIS has been most adept at sending laboratory test orders to lab instruments, tracking those orders, and then recording the results to a searchable database.<br></p>
							<div class="readmore-pro"><a href="lis-detail.php">Read More</a></div>
						</div>
					</div>
					<div class="clearfix visible-md"></div>
					<div class="col-md-3 pad-10-fix s2-marg-btm">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bg-box pad-10-fix text-center "><img src="img/products/crm.jpg" class="img-rounded img-fluid">
					 <h4 class="head-main-sub-intro">Clinical Record</h4>
						<hr class="s2-hr">
					  <p class="whyuspara text-justify"><strong>Clinical Record Management</strong>, defines the storage recommendations which will ensure that records are 
					  maintained, managed and controlled effectively in accordance with the needs of the pre-hospital emergency care practitioner and services in terms 
					  of legal...<br><br></p>
						<div class="readmore-pro"><a href="cr-detail.php">Read More </a></div>
					</div>
					</div>
					<div class="col-md-3 pad-10-fix s2-marg-btm">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bg-box pad-10-fix text-center "><img src="img/products/rx.jpg" class="img-rounded img-fluid">
					 <h4 class="head-main-sub-intro">PMIS</h4>
						<hr class="s2-hr">
					 <p class="whyuspara text-justify"><strong>Pharmacy Management and Information System - PMIS</strong>, A system which tracks the medicine records to all the patients, 
					 In-Patients and Out-Patients recording the actual sales, profit, loss, store management and more.<br><br> <br></p>
						<div class="readmore-pro"><a href="pmis-detail.php">Read More</a></div>
					</div>
					</div>					
				</div>
			</div>
		</div>	
	</section>
	<section class="inner-sec1 sec-pad-top sec-pad-btm in-sec-bg">
		<div class="wrap-product-content">
			<div class="container-fluid container-fluid2">
				<div class="row">				
   				 <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h3 class="whyus-tit">For <strong>Schools and Colleges</strong> </h3>
   				 </div>
					<div class="col-md-3 s2-marg-btm pad-10-fix">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bg-box pad-10-fix text-center "><img src="img/products/mcislogin.jpg" class="img-rounded img-fluid">
						<h4 class="head-main-sub-intro">SMIS</h4>
							<hr class="s2-hr">
							 <p class="whyuspara text-justify"><strong>Student Management Information System – MiDas SMIS </strong> is a complete system that manages the data of students and their financial and academic activities to run your educational institution effectively...
								</p>
							 <div class="readmore-pro"><a href="smis-detail.php">Read More </a></div>
						</div>
						</div>
					<div class="col-md-3 s2-marg-btm pad-10-fix">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bg-box pad-10-fix text-center "><img src="img/products/cmis.jpg" class="img-rounded img-fluid">
						<h4 class="head-main-sub-intro">CMIS</h4>
							<hr class="s2-hr">
							 <p class="whyuspara text-justify"><strong>College Management Information System - MiDas CMIS</strong>, is a complete system that manages the data of college students and their financial and academic activities to run your institution effectively...<br></p>
							<div class="readmore-pro"><a href="cmis-detail.php">Read More </a></div>
						</div>
					</div>
					<div class="col-md-3 s2-marg-btm pad-10-fix">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bg-box pad-10-fix text-center "><img src="img/products/scis.jpg" class="img-rounded img-fluid">
					<h4 class="head-main-sub-intro">SCIS</h4>
						<hr class="s2-hr">
							 <p class="whyuspara text-justify"><strong>School Communication Information System – MiDas SCIS </strong>is a platform where important information can be transfer among stakeholders...<br><br><br>
					</p>
						<div class="readmore-pro"><a href="scis-detail.php">Read More </a></div> 
						</div>
					</div>
					<div class="col-md-3 s2-marg-btm pad-10-fix">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 bg-box pad-10-fix text-center "><img src="img/products/lms.jpg" class="img-rounded img-fluid">
						<h4 class="head-main-sub-intro">LMS</h4>
							<hr class="s2-hr">
							 <p class="whyuspara text-justify"><strong>Library Management System - LMS</strong>, is an enterprise resource planning system for a library, 
							 used to track items owned, orders made, bills paid, and patrons who have borrowed...<br><br></p>
						<div class="readmore-pro"><a href="lms-detail.php">Read More </a></div>
						</div>
					</div>				
				</div>				
			</div>
		</div>	
	</section>
<?php include 'footer.php'; ?>
</div>
<?php include 'loadjs.php' ?>
</body>
</html>
