
<?php include 'head.php'; ?>
<body>
<div class="container-fluid pad-fix">
<!--	Navbar     -->
<?php include 'nav.php'; ?>
<!--navbar ends-->
	<section class="inner-sec1 sec-pad-top sec-pad-btm" ng-controller="NavController">
		<div class="wrap-abt-content">
			<div class="container-fluid container-fluid2">
				<div class="row">
				<div class="col-md-6">
					<div class="left-img">
						<img src="img/abt-banner.png" class="img-fluid">
					</div>
				</div>
				<div class="col-md-6">
					<div class="abt-content" ng-repeat="item in pages | filter:'about'">
						<h1 class="abt-h1">{{item.title}}</h1>
						<hr class="s6-hr">
						<p class="abt-p">{{item.paragraph}}</p>
					</div>
				</div>
			</div>
			</div>
			
			
		</div>	
	</section>



<?php include 'footer.php'; ?>
</div>
<?php include 'loadjs.php' ?>
</body>
</html>
