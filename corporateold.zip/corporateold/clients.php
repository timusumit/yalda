
<?php include 'head.php'; ?>
<body>
<div class="container-fluid pad-fix">
<!--	Navbar     -->
<?php include 'nav.php'; ?>
<!--navbar ends-->
	<section class="inner-sec1 sec-pad-top " ng-controller="NavController">
		<div class="wrap-client-content">
			<div class="container-fluid container-fluid2">
				<div class="row">
					<div class="col-md-6">
						<div class="left-img">
							<img src="img/abt-banner.png" class="img-fluid">
						</div>
					</div>
					<div class="col-md-6">
						<div class="abt-content" ng-repeat="item in pages | filter:'products'">
							<h1 class="client-h1">{{item.title}}</h1>
							<hr class="s6-hr">
							<p class="abt-p">{{item.paragraph}}</p>
						</div>
					</div>
				</div>
			</div>
		</div>	
	</section>
	<section class="inner-sec1 sec-pad-top sec-pad-btm">
		<div class="wrap-client-content">
			<div class="container-fluid container-fluid2">
				<div class="row">
					<div class="col-md-12">
						<h1 class="client-h1">List of our clients</h1>
						<div class="clearfix">
						</div>
						<hr class="s6-hr">
					</div>
					<div class="col-md-5">
						<div class="list-clients" id="hospitals">							
								<a class="client-tit-hosp"><h2>Hospitals</h2></a>
								<h4>Government Hospitals</h4>
									<ul class="hosp-list">
										<li>	National Academy of Medical Sciences ( Bir Hospital), Mahaboudha, Kathmandu	</li>
										<li> Bhaktapur  Hospital, Bhaktapur </li>
										<li>	T.U Teaching Hospital, Maharajgung, Kathmandu	</li>
										<li>	Kanti Children’s Hospital, Maharajgung, Kathmandu	</li>
										<!-- <li>	Maternity Hospital, Thapathali, Kathmandu 	</li> -->
										<li>	Western Regional Hospital, Ramghat, Pokhara	</li>
										<li>	Koshi Zonal Hospital, Biratnagar	</li>
										<li>	Mechi Zonal Hospital, Jhapa	</li>
										<li>	Manmohan Cardio Vascular Transplant Center, Maharajgung,	Kathmandu</li>
										<li>	Civil Service Hospital, Minbhawan, Kathmandu	</li>
										<li>	National Public Health Laboratory, Teku, Kathmandu	</li>
										<li>	B.P. Koirala Lions Centre for Ophthalmic Studies, Maharajgung, Kathmandu	</li>
										<li>	Bir Hospital Trauma Center, Mahaboudha, Kathmandu	</li>
										<li>	Rapti Sub Regional Hospital, Dang, Nepal	</li>
									</ul>
								   <h4>Medical Colleges</h4>
								   <ul class="hosp-list">
									   <li>	Manipal Education &amp; Medical Group (Nepal) Pvt.Ltd. Pokhara, Nepal	</li>
										<li>	Chitwan Medical College  &amp; Teaching Hospital, Bharatpur, Chitwan	</li>
										<li>	College of Medical science &amp; Teaching Hospital, Chitwan	</li>
										<li>	Janaki Medical College &amp; Teaching  hospital, Janakpur	</li>
										<li>	Kist Medical College &amp; Teaching Hospital, Gwarko,	Lalitpur</li>
										<li>	Nobel Medical College &amp; Teaching Hospital, Biratnagar	</li>
										<li>	Kathmandu Medical College &amp; Teaching Hospital, Sinamangal, Kathmandu	</li>
										<li>	Nepal Medical College &amp; Teaching Hospital, Attarkhel, Kathmandu	</li>
										<li>	Nepal Army Medical College &amp; Teaching Hospital, Bhandarkhal, Swoyambhu, Kathmandu	</li>
										<li>	Lumbini Medical College &amp; Teaching Hospital, Palpa, Tansen	</li>
										<li>	Manmohan Medical College &amp; Teaching Hospital, Swoyambhu, Kathmandu	</li>
										<li>	B&amp;C Medical College Teaching Hospital &amp; Research Center, Birtamod, Nepal 	</li>
									</ul> 
         						   <h4>Private Hospitals</h4>      
								   <ul class="hosp-list">
											<li>	Om Hospital &amp; Research Centre (P.) Ltd., Chabahil, Kathmandu	</li>
											<li>	Medicare National Hospital Chabahil Neuro Hospital, Bansbari, Kathmandu	</li>
											<li>	B&amp;B Hospital Pvt. Ltd, Kathmandu	</li>
											<li>	Manmohan Memorial Community  Hospital, Thamel, Kathmandu	</li>
											<li>	Scheer Memorial Hospital, Banepa, Kavre	</li>
											<li>	Dhulikhel Hospital, Dhulikhel, Kavre	</li>
											<li>	Stupa Community Hospital, Jorpati, Kathmandu	</li>
											<li>	Alka Hospital Pulchowk Sumeru City Hospital, Pulchowk, Lalitpur 	</li>
											<li>	Hams Hospital, Buddhanagar,	Kathmandu</li>
											<li>	Himalayan Health Care, Illam,	Nepal</li>
											<li>	Janamaitri Hospital, Balaju,	Kathmandu</li>
											<li>	MiDat Hospital, Lagankhel, Lalitpur</li>
											<li>	Ciwec International Clinic, Lainchour,	Kathmandu</li>
											<li>	Suvekchya International Hospital,  Sitapilla,	Kathmandu</li>
											<li>	Vinayak Hospital &amp; Maternity Home, Samakoshi, Kathmandu</li>
											<li>	Shechen Hospice, Bouddha,	Kathmandu</li>
											<li>	Grace Hospital, Chabahil,	Kathmandu</li>
											<li>	Peoples General Hospital, Nayabazar,	Kathmandu</li>
											<li>	Spark Health Home Hospital, Teku,	Kathmandu</li>
											<li>	Diabetes Thyroid &amp; Endocrinology Care Centre, Kupondole, Kathmandu	</li>
											<li>	Krown Patho Lab, Kathmandu	</li>
											<li>	Nobel Hospital &amp; Research Center, Sinamangal,	Kathmandu</li>
											<li>	Welcare Hospital, Maitidevi,	Kathmandu</li>
											<li>	People Dental College	</li>
											<li>	Lumbini City Hospital &amp; Research Center, Butwal, Nepal	</li>
											<li>	Sumeru Hospital, Dhapakhel, Lalitpur	</li>
											<li>	Sumeru City Hospital, Jawalakhel, Lalitpur 	</li>
											<li>	Kathmandu Ent Hospital, Bagbazar, Kathmandu 	</li>
											<li>	Chirayu National  Hospital &amp; Medical Institute, Basundhara,	Kathmandu</li>
											<li>	Dhirghayu Guru Hospital &amp; Research Center, Chabahil, Kathmandu	</li>
											<li>	Gautam Buddha Community Hospital, Butwal 	</li>
											<li>	Fewa City Hospital, Pokhara, Kaski,	Nepal</li>
											<li>	United Reference Laboratory 	</li>
											<li>	Mangalam Path Lab, Birjgunj, Nepal	</li>
											<li>	Kathmandu Path Lab, Nagpokhari, Kathmandu	</li>
											<li>	Neuro Cardio Multi-Specialty Hospital Pvt Ltd, Biratnagar, Nepal 	</li>
											<li>	Bhaktapur Cancer Hospital, Bhaktapur, Nepal	</li>
											<li>	Nidan Hospital, Pulchowk, Kathmandu, Nepal	</li>
											<li>	Meridian Hospital, Mahargunj, Kathmandu, Nepal	</li>
									</ul>	            			
						</div>
					</div>
					<div class="col-md-7">
						<div class="list-clients" id="schollege">							
								<a class="client-tit-sch">
								<h2>Schools/Colleges</h2>
								</a>
                       			<ul class="sch-list scroll-able">
										<li>	Bibhuti International School	</li>
										<li>	SBBR	</li>
										<li>	Leads Academy	</li>
										<li>	Sewa Sadan Boarding School</li>
										<li>	Uniglobe College (Science)	</li>
										<li>	EXCELSIOR SCHOOL	</li>
										<li>	SOUTHWESTERN SCHOOL	</li>
										<li>	East Point Academy	</li>
										<li>	LITTLE BUDDHA COLLEGE of Health Science	</li>
										<li>	Manmohan Institute of Health Science 	</li>
										<li>	Southwestern State College	</li>
										<!-- <li>	Mount Everest Higher Secondary School	</li> -->
										<li>	Fewacity Institite of medical science	</li>
										<li>	Universal English Boarding High School	</li>
										<li>	Chahana Try Secondary School	</li>
										<li>	Bernhardt International College	</li>
										<li>	Glad Stone Academy	</li>
										<li>	Trinity Int’l College	</li>
										<li>	Shangri-La Orphanage Home,	</li>
										<li>	Springdale English Boarding School	</li>
										<li>	Nexus International School	</li>
										<li>	Uniglobe College 	</li>
										<li>	Swati Sadan School	</li>
										<li>	IST College	</li>
										<li>	Saipal Academy	</li>
										<li>	KEBS School	</li>
										<li>	Awarness Intl Academy	</li>
										<li>	Bernhardt International College	</li>
										<li>	HIMS school	</li>
										<li>	HIMS College	</li>
										<li>	Lords Light Academy	</li>
										<li>	Bajra Academy	</li>
										<li>	Manipal 	</li>
										<li>	Creative Academy	</li>
										<li>	I.J. Pioneer School	</li>
										<li>	Advance Engineering College 	</li>
										<li>	Nirvana Academy	</li>
										<li>	Kantipur Academy School	</li>
										<li>	Gothatar English Boarding School	</li>
										<li>	Quest International College 	</li>
										<li>	Vidya Sadan School	</li>
										<li>	Golden Gate College	</li>
										<li>	MID VALLEY COLLEGE OF HOTEL MANAGEMENT	</li>
										<li>	Nagarjuna	</li>
										<li>	Blooming Buds Int’l School	</li>
										<li>	White House  HS College	</li>
										<li>	Platinum College	</li>
										<li>	Kathmandu Model College 	</li>
										<li>	Progressive English Preparatory School	</li>
										<li>	Active English School</li>
										<li>	Lotus Eyes Tiny Tots Eng. Sec. School	</li>
										<li>	Kathmandu International School	</li>
										<li>	Advance English Boarding School	</li>
										<li>	Anandakuti Viddhapith	</li>
										<li>	Asian College 	</li>
										<li>	BABA Boarding High School	</li>
										<li>	Baneshwor Campus	</li>
										<li>	Bhadrakali English Medium School	</li>
										<li>	Capital College and Research Center 	</li>
										<li>	Dreamland Public School	</li>
										<li>	Ekata James English Academy	</li>
										<li>	Euro International School	</li>
										<li>	Future Star High School	</li>
										<li>	Ganga English School	</li>
										<li>	Genuine Secondary School.	</li>
										<li>	Global College	</li>
										<li>	Golden Gate College (Sinamangal)	</li>
										<li>	Golden Peak High School	</li>
										<li>	Green land International School	</li>
										<li>	Himalayan Institute of Science &amp; Technologies	</li>
										<li>	Himalayan Vidya Mandir 	</li>
										<li>	Himalayan White Int'l College (+2)	</li>
										<li>	Himalayan Whitehouse	</li>
										<li>	Hope Valley Scholars Academy	</li>
										<li>	K&amp;K Education 	</li>
										<li>	Kamana International College	</li>
										<li>	Kanjirowa National School	</li>
										<li>	Kantipur City College</li>
										<li>	Kathmandu Engineering College	</li>
										<li>	Kathmandu Lincoln College	</li>
										<li>	Kathmandu Lincoln School	</li>
										<li>	Kathmandu Model School	</li>
										<li>	Kathmandu School of Law	</li>
										<li>	KIST College	</li>
										<li>	KMC College (BBA)	</li>
										<li>	Lumbini English School	</li>
										<li>	Mahakabi Devkota Memorial	</li>
										<li>	Matribhumi Boarding School</li>
										<li>	Namgyal Middle Secondary School	</li>
										<li>	NASA International College+2	</li>
										<li>	National College 	</li>
										<li>	National Model Science School	</li>
										<li>	National School of Science (MGMT)	</li>
										<li>	National School of Science (Science)	</li>
										<li>	Neric School	</li>
										<li>	New Summit College	</li>
										<li>	Nightingale Higher Secondary Boarding School	</li>
										<li>	NIHS (STUPA COLLEGE)	</li>
										<li>	North Point Academy	</li>
										<li>	Norvic Institute of Nursing Education	</li>
										<li>	Occidental Public School	</li>
										<li>	Om Health Campus	</li>
										<li>	Omega College	</li>
										<li>	Omega School	</li>
										<li>	Orient College	</li>
										<li>	Panga Secondary School	</li>
										<li>	Paragon Public School 	</li>
										<li>	Pashupati Multiple Campus	</li>
										<li>	Patan Academy of Health Science	</li>
										<li>	Popular Gloryland English School	</li>
										<li>	Pragati Pathashala 	</li>
										<li>	Prithwi Secondary Boarding School 	</li>
										<li>	Public Youth College 	</li>
										<li>	Reliance Academy	</li>
										<li>	Sanskar National School/ kids care	</li>
										<li>	Saraswoti Higher Secondary School	</li>
										<li>	Satya Sai Sikshya Sadan	</li>
										<li>	SEBS School	</li>
										<li>	Shivapuri Secondary School 	</li>
										<li>	Shree Bajrayoginee Secondary School	</li>
										<li>	Shree Mahankal Secondary School	</li>
										<li>	Teresa Academy	</li>
										<li>	Times College 	</li>
										<li>	Ursa Major English School	</li>
										<li>	Valley Public School	</li>
										<li>	Valley View English School	</li>
										<li>	White House H.S. School 	</li>
										<li>	White House School of Engineering 	</li>
										<li>	WhiteHouse School of Hotel Management 	</li>
										<li>	Adarsha punja School	</li>
										<li>	CENTRAL ENGINEERING CAMMPUS	</li>
										<li>	Mills Berry School	</li>
										<li>	Bernhardt MTI School	</li>
										<li>	Saipal Academy (college)	</li>
										<li>	Bernhardt International College (school)	</li>
										<li>	CVM School	</li>
										<li>	Vidya Bikash English Secondary School	</li>
										<li>	Intensive international Academy 	</li>
										<li>	Shine model secondary school	</li>
										<li>	CCRC Higher secondary school	</li>
									</ul>
						</div>
					</div>
				</div>				
			</div>
		</div>	
	</section>


<?php include 'footer.php'; ?>
</div>
<?php include 'loadjs.php' ?>
</body>
</html>
