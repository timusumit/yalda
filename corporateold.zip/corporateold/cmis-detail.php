<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<body>
<div class="container-fluid pad-fix">
<!--	Navbar     -->
<?php include 'nav.php'; ?>
<!--navbar ends-->
	<section class="inner-sec1 sec-pad-top sec-pad-btm">
		<div class="wrap-comon-content">
			<div class="container-fluid container-fluid2">
				<div class="row">
				<div class="col-md-6">
					<div class="left-img">
						<img src="img/products/cmis-detail.jpg" class="img-fluid width-100">
					</div>
				</div>
				<div class="col-md-6">
					<div class="cmn-content">
						<h1 class="cmn-h1">CMIS</h1>
						<hr class="s6-hr">
						<p class="cmn-p">
							 		<strong>College Management Information system - MiDas CMIS</strong>, is a complete system that manages the data of college students and their financial and academic activities to run your institution effectively.<br>
									<strong>College Management Information System- MiDas CMIS will have following modules: </strong><br>
						</p>
						<ul class="cmn-ul">
						<li><strong>Student Profile</strong>
								<ul>
									<li>Student Details</li>
									<li>Student Address</li> 
									<li>Academic History</li>
									<li>Parent &amp; Guardian’s Details</li> 
									<li>Further Education</li>
									<li>Employment</li>
								</ul>
							</li>
							<li><strong>Academic Records</strong>
								<ul>
									<li>Attendance Capture</li>
									<li>Mark Capture</li>
									<li>Mark Verification</li>
									<li>Remarks Entry</li>
									<li>Mark Derivation</li> 
									<li>Mark Ledger</li>
									<li>Mark Sheet</li>
								</ul>
							</li>

							<li><strong>Student Account</strong>
							<ul>
							<li>Student Account Setup</li>
							<li>Bill Generation</li> 
							<li>Bill Payment</li> 
							<li>Student Transaction</li>
							<li>Due Bills</li> 
							<li>Reminder Bills</li>
							<li>Daily Collection</li> 
							<li>Miscellaneous Transaction</li>
							<li>Income Details</li> 
							<li>Day Book</li>
							<li>Monthly Due Report</li>
							<li>Scholarship &amp; Discount Report</li>
							</ul>
							</li>
						</ul>
					</div>
				</div>
			</div>
			</div>
			
			
		</div>	
	</section>



<?php include 'footer.php'; ?>
</div>
<?php include 'loadjs.php' ?>
</body>
</html>
