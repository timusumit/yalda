<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<body>
<div class="container-fluid pad-fix">
<!--	Navbar     -->
<?php include 'nav.php'; ?>
<!--navbar ends-->
	<section class="inner-sec1 sec-pad-top sec-pad-btm">
		<div class="wrap-comon-content">
			<div class="container-fluid container-fluid2">
				<div class="row">
				<div class="col-md-6">
					<div class="left-img">
						<img src="img/products/rx.jpg" class="img-fluid width-100">
					</div>
				</div>
				<div class="col-md-6">
					<div class="cmn-content">
						<h1 class="cmn-h1">PMIS</h1>
						<hr class="s6-hr">
						<p class="cmn-p">
								<strong>Pharmacy Management and Information System - PMIS</strong>, A system which tracks the medicine records to all the patients, 
								 In-Patients and Out-Patients recording the actual sales, profit, loss, store management and more. To control loss and damage, there should 
								 multi-level pharmacy store in a hospital. Main Pharmacy should purchase from party and issue to billing stores. Billing stores should sale to
								 customers and issue to wards. This system handles multi-store/counter pharmacy.<br>          
								<strong>This module handles following functions:</strong>
						</p>
						<ul class="cmn-ul">
							<li><strong>Category, Brand and Item wise Sales Analysis.</strong></li>
							<li><strong>Counter wise cash and credit sales</strong></li>
							<li><strong>User wise cash collection.</strong></li>
							<li><strong>Store wise stock analysis.</strong></li>
							<li><strong>Expiry and Damage analysis.</strong></li>
							<li><strong>Category, Brand and Item wise profit analysis.</strong> </li> 
							<li><strong>Supplier wise profit analysis.</strong> </li>
							<li><strong>Supplier payment analysis.</strong> </li>
						</ul>
					</div>
				</div>
			</div>
			</div>
			
			
		</div>	
	</section>



<?php include 'footer.php'; ?>
</div>
<?php include 'loadjs.php' ?>
</body>
</html>
