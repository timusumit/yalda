<script src="js/jquery.min.js"></script>
<script src="js/parallax.js"></script>

<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script src="js/wow.js"></script>
