<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<body>
<div class="container-fluid pad-fix">
<!--	Navbar     -->
<?php include 'nav.php'; ?>
<!--navbar ends-->
	<section class="inner-sec1 sec-pad-top sec-pad-btm">
		<div class="wrap-comon-content">
			<div class="container-fluid container-fluid2">
				<div class="row">
				<div class="col-md-6">
					<div class="left-img">
						<img src="img/products/scis-flowchart.jpg" class="img-fluid width-100">
					</div>
				</div>
				<div class="col-md-6">
					<div class="cmn-content">
						<h1 class="cmn-h1">SCIS</h1>
						<hr class="s6-hr">
						<p class="cmn-p">
					<strong>School Communication Information System – MiDas SCIS </strong>is a platform where important information can be transfer among stakeholders ( School Management, Teachers, Students and Parents) through Internet or SMS service.
					This information is captured in MiDas Student Management Information System can be accurately transferred to concerned stakeholders of the school by using Web application and Mobile application. Using this system the stakeholders can communicate between them through Internet and SMS. 
					It also has Online Communication Scheduling System, which manages time for LIVE communication between the parents and corresponding teachers. Once the appointment is confirmed, parents and teachers can communicate ONLINE  through Viber or Skype.
					This application is designed with an aim to meet your communication objectives by providing an effective communications.<br> 

						</p>
						
					</div>
				</div>
			</div>
			</div>
			
			
		</div>	
	</section>



<?php include 'footer.php'; ?>
</div>
<?php include 'loadjs.php' ?>
</body>
</html>
