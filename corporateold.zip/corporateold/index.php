

<?php
include 'head.php';
?>
<body>
<div class="container-fluid pad-fix">

<!--	Navbar     -->
<?php
include 'nav.php';
?>
<!--navbar ends-->

<!--section1 banner	-->
	<section class="section1 sec-mrg-btm" ng-controller="NavController">
		<div class="top-banner">
			<div class="col-lg-7 col-md-7 col-sm-7 banner-content s6-ryt-item item-mrg-btm  wow fadeInRight animated">
				<div class="s1-top-banner-content" ng-repeat="item in pages | filter:'home'">
  				<h1 class="banner-title" >{{item.title}}</h1>
  				<h4 class="banner-c">{{item.paragraph}} </h4>
  				<br><br>
  				<div class="link2more">
  					<a  class="" href="about.php">
  						Explore More About us
  					</a>
  				</div>
				</div>
			</div>

	  </div>
	</section>
<!--section1 banner ends	-->

<!--section2 banner-->
	<section class="section2 sec-mrg-btm" id="section2">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
			<h1 class="sec-title text-center title-mrg-btm"><strong>What</strong> we can offer</h1>
		</div>
		<div class="container-fluid container-fluid2">
			<div class="row">
			<div class="col-md-4 s2-marg-btm wow fadeInLeft animated">
				<div class="w-s2-item text-center get-s2-height">
					<div class="s2-item-img">
						<img src="img/business-solution.png" alt="Business Solutions" class="img-fluid">
					</div>
					<hr class="s2-hr">
					<div class="s2-item-ttl">
						<h3>
							<span>
								<strong>Business </strong> Solutions
							</span>

						</h3>
					</div>
					<div class="s2-item-content">
						<p>In today's business environment the only constant
						 is the change. Business managers in order to
						manage the change need access to factual
						information in real-time. MiDas Technologies
						Pvt. Ltd., a member of MiDas Group helps business
						 managers to take more effective decisions by
						 converting multiple sources of data into useful...</p>
					</div>
					<div class="read-more">
					<a href="#"><strong>Read More</strong></a>
					</div>
				</div>
			</div>
			<div class="col-md-4 s2-marg-btm wow fadeInUp animated">
				<div class="w-s2-item text-center set-s2-height">
					<div class="s2-item-img">
						<img src="img/software-developement.png" alt="Software Development" class="img-fluid">
					</div>
					<hr class="s2-hr">
					<div class="s2-item-ttl">
						<h3>
							<span>
								<strong>Software </strong> Development
							</span>

						</h3>
					</div>
					<div class="s2-item-content">
						<p>In today's business environment the only constant
						 is the change. Business managers in order to
						manage the change need access to factual
						information in real-time. MiDas Technologies
						Pvt. Ltd., a member of MiDas Group helps business
						 managers to take more effective decisions by
						 converting multiple sources of data into useful...</p>
					</div>
					<div class="read-more">
					<a href="#"><strong>Read More</strong></a>
					</div>
				</div>
			</div>
			<div class="col-md-4 s2-marg-btm wow fadeInRight animated">
				<div class="w-s2-item text-center set-s2-height">
					<div class="s2-item-img">
						<img src="img/client-support.png" alt="Client Support" class="img-fluid">
					</div>
					<hr class="s2-hr">
					<div class="s2-item-ttl">
						<h3>
							<span>
								<strong>Client </strong> Support
							</span>

						</h3>
					</div>
					<div class="s2-item-content">
						<p>In today's business environment the only constant
						 is the change. Business managers in order to
						manage the change need access to factual
						information in real-time. MiDas Technologies
						Pvt. Ltd., a member of MiDas Group helps business
						 managers to take more effective decisions by
						 converting multiple sources of data into useful...</p>
					</div>
					<div class="read-more">
					<a href="#"><strong>Read More</strong></a>
					</div>
				</div>
			</div>
		</div>
		</div>
	</section>
<!--section2 banner ends-->

<!--section3 banner-->
	<section class="section3 sec-mrg-btm sec-pad-btm">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
			<h1 class="sec-title text-center title-mrg-btm title-pad-top "><strong>Why</strong> Choose MiDas ?</h1>
		</div>
		<div class="container-fluid container-fluid2 ">
			<div class="row">
			<div class="col-md-7">
				<div class="w-s3-left-item">
					<div class="row">
					<div class="col-md-2">
						<div class="s3-item-img">
							<img src="img/easy2use.png" alt="East to use" class="">
						</div>
					</div>
					<div class="col-md-10">
						<div class="s3-item-title">
							<h4>Our products are easy to use</h4>
						</div>
						<div class="s3-item-content">
							<p>Our staff are selected from the highest qualified personnel available.
							We know the technology and how to develop software. We use the best
							practices of worldwide software development technology. The quality
							is predictable and extremely reliable.</p>
						</div>
					</div>
					</div>
				</div>
				<div class="w-s3-left-item">
					<div class="row">
					<div class="col-md-2">
						<div class="s3-item-img">
							<img src="img/quality.png" alt="East to use" class="">
						</div>
					</div>
					<div class="col-md-10">
						<div class="s3-item-title">
							<h4>Quality</h4>
						</div>
						<div class="s3-item-content">
							<p>Our staff are selected from the highest qualified personnel available.
							We know the technology and how to develop software. We use the best
							practices of worldwide software development technology. The quality
							is predictable and extremely reliable.</p>
						</div>
					</div>
					</div>
				</div>
				<div class="w-s3-left-item">
					<div class="row">
					<div class="col-md-2">
						<div class="s3-item-img">
							<img src="img/no-hampered.png" alt="East to use" class="">
						</div>
					</div>
					<div class="col-md-10">
						<div class="s3-item-title">
							<h4>No hampered communications</h4>
						</div>
						<div class="s3-item-content">
							<p>Our staff are selected from the highest qualified personnel available.
							We know the technology and how to develop software. We use the best
							practices of worldwide software development technology. The quality
							is predictable and extremely reliable.</p>
						</div>
					</div>
					</div>
				</div>
				<div class="w-s3-left-item">
					<div class="row">
					<div class="col-md-2">
						<div class="s3-item-img">
							<img src="img/long-term.png" alt="East to use" class="">
						</div>
					</div>
					<div class="col-md-10">
						<div class="s3-item-title">
							<h4>We are here for the long term</h4>
						</div>
						<div class="s3-item-content">
							<p>Our staff are selected from the highest qualified personnel available.
							We know the technology and how to develop software. We use the best
							practices of worldwide software development technology. The quality
							is predictable and extremely reliable.</p>
						</div>
					</div>
					</div>
				</div>
			</div>
			<div class="col-md-5">
				<div class="s3-side-img">
					<img src="img/s3-side-img.png" alt="Customer" class="img-fluid">

				</div>
			</div>

		</div>
		</div>
	</section>
<!--section3 banner ends-->

<!--section4 banner-->
	<section class="section4 sec-mrg-btm sec-pad-btm">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 sec-pad-btm ">
			<h1 class="sec-title text-center"><strong>MiDas </strong>on Education</h1>
			<h4 class="sec-title text-center"> Lorem Ipsum is simply dummy text of the printing and typesetting industry.  </h4>
		</div>
		<div class="container-fluid container-fluid2 ">
			<div class="row">
			<div class="col-md-6 mob-marg-btm">
				<div class="w-s4-left-item  wow fadeInLeft animated">
					<div class="s4-item-title">
						<h4>
							<span class="border-btm">
								<strong>MiDas eCLASS </strong>The Learning Platform
							</span>
						</h4>
					</div>
					<div class="s4-item-content">
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting
							industry. </p>
						<p>
						Lorem Ipsum has been the industry's standard dummy text
						ever since the 1500s, when an unknown printer took a galley of type
						and scrambled it to make a type specimen book. It has survived not
						 only five centuries, but also the leap into electronic typesetting,
						 remaining essentially unchanged.</p>
					</div>
					<div class="s4-readmore">
						<a href="#" class="" ><strong>Read More</strong></a>
					</div>
					<div class="s4-btns">
						<a href="http://midas.com.np/login" target="_blank" class="s4-join-now link-btn">Join Now</a>

						<a href="https://play.google.com/store/apps/details?id=com.midas.midasstudent&hl=en" target="_blank" class="s4-join-now"><img src="img/playstore.png" width="110" alt="Midas eCLASS" class="playstore-btn"></a>

					</div>

				</div>
			</div>
			<div class="col-md-6">
				<div class="s4-right-img wow fadeInUp animated">
					<img src="img/sec-4-img.png" class="img-fluid" alt="MiDas on Education">
				</div>
			</div>

		</div>
		</div>
	</section>
<!--section4 banner ends-->

<!--section5 banner-->
	<section class="section5 sec-mrg-btm sec-pad-btm">
		<div class="container-fluid container-fluid2 title-pad-top ">
			<div class="row">
				<div class="col-md-8">
					<h4 class="text-center title-pad-top">You can also get Tutorial Videos of <strong>MiDas eCLASS </strong> on SD CARD,
					Pen Drive and DVD ROM from nearby shops</h4>
				</div>
				<div class="col-md-4">
					<div class="row">
						<div class="col-md-4">
							<div class="s5-circle-img wow rollIn">
								<img src="img/pendrive.png" class="img-fluid" alt="Pendrive">
							</div>
						</div>
						<div class="col-md-4">
							<div class="s5-circle-img wow rollIn">
								<img src="img/sd-card.png" class="img-fluid" alt="Pendrive">
							</div>
						</div>
						<div class="col-md-4">
							<div class="s5-circle-img wow rollIn">
								<img src="img/cd.png" class="img-fluid" alt="Pendrive">
							</div>
						</div>
					</div>
				</div>


			</div>

		</div>
	</section>
<!--section5 banner ends-->


<!--section6 banner-->
	<section class="section6 sec-mrg-btm sec-pad-btm">
		<div class="col-md-12">
			<h1 class="sec-title text-center"><strong>MiDas </strong> Apps</h1>
		</div>
		<div class="container title-pad-top ">
			<div class="row">
				<div class="col-md-6 wow fadeInUp">
					<div class="s6-left-img ">
						<img src="img/midasapps.png" class="img-fluid float-right" alt="MiDas Apps">
					</div>
				</div>
				<div class="col-md-6">
					<div class="s6-ryt-item item-mrg-btm  wow fadeInRight animated">
						<div class="s6-item-title">
							<h4>
								<span class="border-btm">
								<strong>MiDas eCLASS</strong>- The Learning Platform
								</span>

							</h4>
							<hr class="s6-hr">
						</div>
						<div class="s6-item-content">
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting
							industry. Lorem Ipsum is simply dummy text of the printing and typesetting
							industry. </p>
						</div>
						<div class="s6-btns">
						<a  class="read-more link-btn"  data-toggle="modal" data-target="#midaseClass" >Read More</a>
							<a href="https://play.google.com/store/apps/details?id=com.midas.midasstudent&hl=en" class="" target="_blank"><img src="img/playstore.png" class="img-fluid playstore-btn" alt="MiDas App" width="110"></a>
						</div>
					</div>
					<div class="s6-ryt-item item-mrg-btm wow fadeInRight animated">
						<div class="s6-item-title">
							<h4>
								<span class="border-btm">
									<strong>MiDas App</strong>- For Teachers
								</span>

							</h4>
							<hr class="s6-hr">
						</div>
						<div class="s6-item-content">
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting
							industry. Lorem Ipsum is simply dummy text of the printing and typesetting
							industry. </p>
						</div>
						<div class="s6-btns">
						<a href="" class="read-more link-btn" data-toggle="modal" data-target="#app4teacher">Read More</a>
							<a href="https://play.google.com/store/apps/details?id=com.midas.midasteacher&hl=en" class="" target="_blank"><img src="img/playstore.png" class="img-fluid playstore-btn" alt="MiDas App" width="110"></a>
						</div>
					</div>
					<div class="s6-ryt-item item-mrg-btm wow fadeInRight animated">
						<div class="s6-item-title">
							<h4>
								<span class="border-btm">
								<strong>Livestock Farming (पशुपालन)</strong>
								</span>

							</h4>
							<hr class="s6-hr">
						</div>
						<div class="s6-item-content">
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting
							industry. Lorem Ipsum is simply dummy text of the printing and typesetting
							industry. </p>
						</div>
						<div class="s6-btns">
						<a href="" class="read-more link-btn" data-toggle="modal" data-target="#livestock">Read More</a>
							<a href="https://play.google.com/store/apps/details?id=com.midas.cattle&hl=en" class="" target="_blank"><img src="img/playstore.png" class="img-fluid playstore-btn" alt="MiDas App" width="110"></a>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
				<div class="col-md-12">
					<div class="view-all-app text-center">
						<a href="https://play.google.com/store/apps/developer?id=MiDas%20Education%20Pvt.%20Ltd&hl=en" class=""><strong>View All Our Apps</strong></a>

					</div>
				</div>
			</div>
		</div>
	</section>
<!--section6 banner ends-->

<!--section7 banner-->
	<section class="section7 sec-mrg-btm sec-pad-btm">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
			<h1 class="sec-title text-center title-pad-top">Our <strong>Management Information Systems</strong></h1>
			<h4 class="sec-title text-center"> Lorem Ipsum is simply dummy text of the printing and typesetting industry.  </h4>
		</div>
		<div class="container-fluid container-fluid2 title-pad-top ">
			<div class="row">
				<div class="col-md-4 marg-btm">
					<div class="w-s7-item">
						<div class="row">
							<div class="col-5">
								<div class="s7-item-img">
									<img src="img/hmis.png" class="img-fluid" alt="HMIS">
								</div>
							</div>
							<div class="col-5">
								<div class="s7-item-title">
								<h3><a href="hmis-detail.php">
									<strong>Hospital</strong>
								Management Information System
									</a>
									
								</h3>

								</div>

							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 marg-btm">
					<div class="w-s7-item">
						<div class="row">
							<div class="col-5">
								<div class="s7-item-img">
									<img src="img/library.png" class="img-fluid" alt="HMIS">
								</div>
							</div>
							<div class="col-5">
								<div class="s7-item-title">
								<h3>
									<a href="lms-detail.php">
									<strong>Library</strong>
										Management Information System
										</a>
								</h3>

								</div>

							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 marg-btm">
					<div class="w-s7-item">
						<div class="row">
							<div class="col-5">
								<div class="s7-item-img">
									<img src="img/pharmacy.png" class="img-fluid" alt="HMIS">
								</div>
							</div>
							<div class="col-5">
								<div class="s7-item-title">
								<h3>
									<a href="pmis-detail.php">
									<strong>Pharmacy</strong>
								Management Information System
									</a>
								</h3>

								</div>

							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 marg-btm">
					<div class="w-s7-item">
						<div class="row">
							<div class="col-5">
								<div class="s7-item-img">
									<img src="img/laboratory.png" class="img-fluid" alt="HMIS">
								</div>
							</div>
							<div class="col-5">
								<div class="s7-item-title">
								<h3>
									<a href="lis-detail.php">
										<strong>Laboratory</strong>
									Management Information System
										</a>
								</h3>

								</div>

							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 marg-btm">
					<div class="w-s7-item">
						<div class="row">
							<div class="col-5">
								<div class="s7-item-img">
									<img src="img/college.png" class="img-fluid" alt="HMIS">
								</div>
							</div>
							<div class="col-5">
								<div class="s7-item-title">
								<h3>
									<a href="cmis-detail.php">
										<strong>College</strong>
								Management Information System
									</a>
									
								</h3>

								</div>

							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 marg-btm">
					<div class="w-s7-item">
						<div class="row">
							<div class="col-5">
								<div class="s7-item-img">
									<img src="img/empty.png" class="img-fluid" alt="HMIS">
								</div>
							</div>
							<div class="col-5">
								<div class="s7-item-title">
								<h3>
									<strong>Your</strong>
								Management Information System
								</h3>

								</div>

							</div>
						</div>
					</div>
				</div>
				<div class="clearfix"></div>
				<div class="col-md-12">
					<div class="s7-content text-center sec-pad-btm title-pad-top wow fadeInUp">
						<h1 class="s7-title1"><strong>Need IT Solutions ?</strong></h1>
						<h3 class="s7-title2"> Let your problem be ours and our solutions be yours !</h3>
						<h3 class="s7-title2 marg-btm">Let’s Work Together</h3>
						<a href="contacts.php" class="letsconnect link-btn"><strong>Lets Connect</strong></a>
					</div>
				</div>

			</div>
			<img src="img/bulb.png" alt="bulb" class="s7-bulb">
		</div>

	</section>
<!--section7 banner ends-->

	<!--section8 banner-->
	<section class="section8 sec-mrg-btm sec-pad-btm ">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
			<h1 class="sec-title text-center title-pad-top"><strong>Trusted</strong> By</h1>
			<h4 class="sec-title text-center"> Lorem Ipsum is simply dummy text of the printing and typesetting industry.  </h4>
		</div>
		<div class="container-fluid container-fluid2 title-pad-top ">
			<div class="row">
				<div class="col-md-2 mob-marg-btm">
					<div class="s8-client-img">
						<img src="img/clients/client1.jpg" class="img-fluid" alt="Cliets">
					</div>
				</div>
				<div class="col-md-2 mob-marg-btm">
					<div class="s8-client-img">
						<img src="img/clients/client2.jpg" class="img-fluid" alt="Cliets">
					</div>
				</div>
				<div class="col-md-2 mob-marg-btm">
					<div class="s8-client-img">
						<img src="img/clients/client3.jpg" class="img-fluid" alt="Cliets">
					</div>
				</div>
				<div class="col-md-2 mob-marg-btm">
					<div class="s8-client-img">
						<img src="img/clients/client4.jpg" class="img-fluid" alt="Cliets">
					</div>
				</div>
				<div class="col-md-2 mob-marg-btm">
					<div class="s8-client-img">
						<img src="img/clients/client5.jpg" class="img-fluid" alt="Cliets">
					</div>
				</div>
				<div class="col-md-2 mob-marg-btm">
					<div class="s8-client-img">
						<img src="img/clients/client-6.jpg" class="img-fluid" alt="Cliets">
					</div>
				</div>
				<div class="clearfix"></div>
				<div class="col-md-12">
					<div class="view-all-clients text-center title-pad-top">
						<h4><a href="clients.php" class="">View all our Clients</a></h4>
					</div>
				</div>
			</div>
		</div>
	</section>
	<a href="#" class="scrollToTop">Scroll To Top</a>
	<style>
.scrollToTop{
	position: absolute;
	width:100px; 
	height:130px;
	padding:10px; 
	text-align:center; 
	background: whiteSmoke;
	font-weight: bold;
	color: #444;
	text-decoration: none;
	position:fixed;
	top:75px;
	right:40px;
	display:none;
	background: url('arrow_up.png') no-repeat 0px 20px;
}
.scrollToTop:hover{
	text-decoration:none;
}



</style>
<script>
$(document).ready(function(){
	
	//Check to see if the window is top if not then display button
	$(window).scroll(function(){
		if ($(this).scrollTop() > 100) {
			$('.scrollToTop').fadeIn();
		} else {
			$('.scrollToTop').fadeOut();
		}
	});
	
	//Click event to scroll to top
	$('.scrollToTop').click(function(){
		$('html, body').animate({scrollTop : 0},800);
		return false;
	});
	
});



</script>
	<!--section8 banner ends-->
	
<?php
include 'modals.php';
?>
	
<?php
include 'footer.php';
?>




</div>
<?php
include 'loadjs.php'

?>

</body>
</html>
