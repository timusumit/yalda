<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<body>
<div class="container-fluid pad-fix">
<!--	Navbar     -->
<?php include 'nav.php'; ?>
<!--navbar ends-->
	<section class="inner-sec1 sec-pad-top sec-pad-btm">
		<div class="wrap-comon-content">
			<div class="container-fluid container-fluid2">
				<div class="row">
				<div class="col-md-6">
					<div class="left-img">
						<img src="img/products/crm.jpg" class="img-fluid width-100">
					</div>
				</div>
				<div class="col-md-6">
					<div class="cmn-content">
						<h1 class="cmn-h1">Clinical Record</h1>
						<hr class="s6-hr">
						<p class="cmn-p">
							<strong>Clinical Record Management</strong>, defines the storage recommendations which will ensure that records are 
							  maintained, managed and controlled effectively in accordance with the needs of the pre-hospital emergency care practitioner and services in terms 
							  of legal, operational and informational needs. <br>          
							This module handles following functions:
						</p>
						<ul class="cmn-ul">
						<li><strong>Files issued to admitted patients.</strong></li>
						<li><strong>Files collected from discharged patients.</strong></li>
						<li><strong>Files issued to doctors / students / staffs.</strong></li>
						<li><strong>Files collected from doctors / students / staffs.</strong></li>
						<li><strong>Files position tracking.</strong></li>
						<li><strong>Files movement tracking.</strong></li>
						</ul>
					</div>
				</div>
			</div>
			</div>
			
			
		</div>	
	</section>



<?php include 'footer.php'; ?>
</div>
<?php include 'loadjs.php' ?>
</body>
</html>
