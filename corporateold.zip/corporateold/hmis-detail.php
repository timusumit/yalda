<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<body>
<div class="container-fluid pad-fix">
<!--	Navbar     -->
<?php include 'nav.php'; ?>
<!--navbar ends-->
	<section class="inner-sec1 sec-pad-top sec-pad-btm">
		<div class="wrap-comon-content">
			<div class="container-fluid container-fluid2">
				<div class="row">
				<div class="col-md-6">
					<div class="left-img">
						<img src="img/products/hmis.jpg" class="img-fluid width-100">
					</div>
				</div>
				<div class="col-md-6">
					<div class="cmn-content">
						<h1 class="cmn-h1">HMIS</h1>
						<hr class="s6-hr">
						<p class="cmn-p">
							<strong>Hospital Management and Information System - HMIS</strong>, Collection, compilation, analysis and interpretation 
							 of data for effective use as information which helps in better planning, monitoring and control of medical and health services which also helps in improving of the efficiency and Performance of health delivery system.<br>            
							 <strong>Modules We Are Providing</strong><br>
							Our entire project is the integrated system of different modules, based on different tools and techniques. The project is designed in such a way that these modules can be added phase by phase and also has space for further development. <br>We provide MiDas Dr.HoMS for HMIS<br>
							<strong>MiDas Doctor HoMS</strong><br>We provide following modules under MiDas Doctor HoMS:<br>
						</p>
						<ul class="cmn-ul">
						<li><strong>Call Centre </strong></li>
						<li><strong>Patient Appointment</strong></li>
						<li><strong>Customer Care/Information Desk</strong></li>	
						<li><strong>Health Membership</strong></li>			
						<li><strong>Out Patient Registration</strong></li>			
						<li><strong>Follow-Up Patient Registration</strong></li>			
						<li><strong>Emergency Patient Registration System</strong></li>			
						<li><strong>Nurse Triage</strong></li>			
						<li><strong>Out Patient Clinical Information System </strong></li>
						<li><strong>Patient Billing System</strong></li>			
						<li><strong>Patient Admission &amp; Bed Management System</strong></li>
						<li><strong>Nursing Station</strong></li>		
						<li><strong>Operation Theater</strong></li>		
						<li><strong>Patient Nutrition</strong></li>		
						<li><strong>Inpatient Medical Information System </strong></li>		
						<li><strong>Patient Discharge &amp; Billing System</strong></li>		
						<li><strong>Patient Medical Record &amp; Statistics System</strong></li>		
						<li><strong>Vaccine Schedule Information System</strong></li>
						<li><strong>Insurance Tracking System</strong></li>
						</ul>
					</div>
				</div>
			</div>
			</div>
			
			
		</div>	
	</section>



<?php include 'footer.php'; ?>
</div>
<?php include 'loadjs.php' ?>
</body>
</html>
