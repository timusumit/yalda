<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<body>
<div class="container-fluid pad-fix">
<!--	Navbar     -->
<?php include 'nav.php'; ?>
<!--navbar ends-->
	<section class="inner-sec1 sec-pad-top sec-pad-btm">
		<div class="wrap-comon-content">
			<div class="container-fluid container-fluid2">
				<div class="row">
				<div class="col-md-6">
					<div class="left-img">
						<img src="img/products/library-detail.jpg" class="img-fluid width-100">
					</div>
				</div>
				<div class="col-md-6">
					<div class="cmn-content">
						<h1 class="cmn-h1">LMS</h1>
						<hr class="s6-hr">
						<p class="cmn-p">
							<strong>Library Management System - LMS</strong>, is an enterprise resource planning system for a library, 
									 used to track items owned, orders made, bills paid, and patrons who have borrowed.<br>
							<strong>MiDas Library (Library Management Information System) will have following features:</strong><br>
						</p>
						<ul class="cmn-ul">
						<li><strong>Member Information</strong></li>
							<li><strong>Member ID Card Generation</strong>
							<ul>
							<li>With Photographs</li>
							<li>With Barcode</li>
							</ul>
							</li>
							<li><strong>Catalogue Details</strong>
							<ul>
							<li>Books</li>
							<li>Journal</li>
							<li>Video</li>
							<li>Audio</li>
							</ul>
							</li>
							<li><strong>Order Placement</strong></li>
							<li><strong>Acquisition</strong></li>
							<li><strong>Stock Management</strong></li>
							<li><strong>Catalogue Search</strong></li>
							<li><strong>Catalogue Issue/Return</strong></li>
							<li><strong>Catalogue Reservations</strong></li>
							<li><strong>Late Fee</strong></li>
							<li><strong>Library Flow Analyzer</strong></li>
						</ul>
					</div>
				</div>
			</div>
			</div>
			
			
		</div>	
	</section>



<?php include 'footer.php'; ?>
</div>
<?php include 'loadjs.php' ?>
</body>
</html>
