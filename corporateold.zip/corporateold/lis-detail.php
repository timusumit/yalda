<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<body>
<div class="container-fluid pad-fix">
<!--	Navbar     -->
<?php include 'nav.php'; ?>
<!--navbar ends-->
	<section class="inner-sec1 sec-pad-top sec-pad-btm">
		<div class="wrap-comon-content">
			<div class="container-fluid container-fluid2">
				<div class="row">
				<div class="col-md-6">
					<div class="left-img">
						<img src="img/products/lis.jpg" class="img-fluid width-100">
					</div>
				</div>
				<div class="col-md-6">
					<div class="cmn-content">
						<h1 class="cmn-h1">LIS</h1>
						<hr class="s6-hr">
						<p class="cmn-p">
									<strong>Laboratory Information System - LIS</strong>, A software system that records, manages, and stores data for hospital laboratories.
									  A LIS has been most adept at sending laboratory test orders to lab instruments, tracking those orders, and then recording the results, 
									  to a searchable database.<br>           
								 <strong>Modules We Are Providing</strong><br>
								<strong>MiDas Doctor HoMS</strong><br>We provide following modules under MiDas Doctor HoMS for LIS:<br>
						</p>
						<ul class="cmn-ul">
						<li><strong>Investigation Sample Tracking System </strong></li>
						<li><strong>Patient Investigation Reporting System</strong></li>
						</ul>
					</div>
				</div>
			</div>
			</div>
			
			
		</div>	
	</section>



<?php include 'footer.php'; ?>
</div>
<?php include 'loadjs.php' ?>
</body>
</html>
