<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<body>
<div class="container-fluid pad-fix">
<!--	Navbar     -->
<?php include 'nav.php'; ?>
<!--navbar ends-->
	<section class="inner-sec1 sec-pad-top sec-pad-btm">
		<div class="wrap-comon-content">
			<div class="container-fluid container-fluid2">
				<div class="row">
				<div class="col-md-6">
					<div class="left-img">
						<img src="img/products/smis-flowchart.jpg" class="img-fluid width-100">
					</div>
				</div>
				<div class="col-md-6">
					<div class="cmn-content">
						<h1 class="cmn-h1">SMIS</h1>
						<hr class="s6-hr">
						<p class="cmn-p">
							   		<strong>Student Management Information System – MiDas SMIS </strong> is a complete system that manages the data of students and their financial and academic activities to run your educational institution effectively. It is a Desktop application with RDMS ( Relational Database Management System) that store and manages data locally within school premises.
									For day to day operation, users can easily capture information and quickly generate reports within the school premises without internet access on a single click.
									This application is designed to meet your objectives like a highly trustworthy finance department and an active administration<br>    
						</p>
						
					</div>
				</div>
			</div>
			</div>
			
			
		</div>	
	</section>



<?php include 'footer.php'; ?>
</div>
<?php include 'loadjs.php' ?>
</body>
</html>
