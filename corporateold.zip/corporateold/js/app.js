var app= angular.module('myApp',['ngRoute']);

app.controller('NavController',['$scope','$http', function($scope,$http){
	
$http.get('js/content.json').success(function(data){
$scope.pages=data;
});
}]);