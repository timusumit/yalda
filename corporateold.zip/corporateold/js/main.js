//var divHeight = $('#hospitals').height(); 
//$('.sch-list.scroll-able').css('max-height', divHeight+'px');
//$('.sch-list.scroll-able').css('overflow-x', 'auto');
//$('#schollege').css('max-height', divHeight+'px');