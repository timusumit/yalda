
<footer>
	
  <section class="section9 sec-pad-btm mob-pad-top">
    <div class="container-fluid container-fluid2 title-pad-top ">
      <div class="row">
        <div class="col-md-3 mob-marg-btm">
          <div class="s9-item abt-us">
            <div class="s9-item-title">
              <h5>About US</h5>
            </div>
            <div class="s9-item-content">
              <p>
              MiDas Technologies Pvt. Ltd. - A Nepal
              based professionally managed
              company offering IT solutions to local
              as well as overseas clients...
              </p>
              <a href="" class="link-btn">Read More</a>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="s9-item abt-us">
            <div class="s9-item-title">
              <h5>Navigation</h5>
            </div>
            <div class="s9-item-content">
              <ul class="nav-ul">
              <li><a href=""> > Business Solution</a></li>
              <li><a href=""> > Software Development</a></li>
              <li><a href=""> > Client Support</a></li>
              <li><a href=""> > Our Products</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="s9-item abt-us">
            <div class="s9-item-title">
            <div class="s9-item-title">
            <div class="s9-item-title">
              <h5>Get in touch with us</h5>
            </div>
            <div class="s9-item-content">
              <ul class="git-ul">
              <li><a href=""> > +977-01-6216277 </a></li>
              <li><a href=""> > info@midas.com.np</a></li>
              <li><a href=""> > Location map</a></li>

              </ul>

            </div>
          </div>
        </div>

      </div>
    </div>
        <div class="col-md-3">
          <div class="s9-item abt-us">
            <div class="s9-item-title">
              <h5>Corporate</h5>
            </div>
            <div class="s9-item-content">
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="section10">
    <div class="container-fluid container-fluid2">
      <div class="row">
        <div class="col-md-12 text-center">
          <h6>
            MiDas Technologies Pvt. Ltd. © 2018
          </h6>
        </div>
      </div>
    </div>
  </section>
</footer>
