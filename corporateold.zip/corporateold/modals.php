<!-- Button trigger modal -->
<!--
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#midaseClass">
  Launch demo modal
</button>
-->

<!-- MiDas eCLass Modal -->
<div class="modal fade" id="midaseClass" tabindex="-1" role="dialog" aria-labelledby="MiDaseCLASS" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle"><strong>MiDas eCLASS </strong>- The Learning Platform</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
		
      </div>
		
      <div class="modal-body">
        <div class="m-desc">
		  MiDas - The Learning App is developed to meet all types of educational needs of Nursery to Grade 10 students and their parents. <br>

It includes Curriculum based Study Materials, Communication Tools and Talent Show Platform.<br>

---- Animated Video Lessons are Approved by CDC, Govt. of Nepal ---<br>

MiDas eCLASS मा के छ? <br>
===================<br>
✓ Homework गर्न सिकाउन Online Teachers <br>
✓ किताबको पाठ बुझाउन Animated Video Lessons<br>
✓ Problem Solve गर्न सिकाउन Tutorial Classes<br>
✓ खेलाउदै सिकाउन Quizzes & Games<br>
✓ परीक्षामा धेरै Mark ल्याउन Practice Exam QAs<br>
✓ बच्चाले कति पढे थाहा पाउन Graphical Analysis <br>

MiDas eCLASS ले विद्यार्थीहरुको पढाइमा सुधार कसरी ल्याउछ? <br>
=============================================<br>
विध्यार्थीहरूको पढाइमा सुधार ल्याउन उनिहरूलाई पढाइमा रूची जगाउने किसिमको पाठ्य सामग्री दिन आवश्यक छ। साथै उनिहरू पढ्न बसेको बेलामा केही जानेनन् भने तुरून्त सिकाउने ब्यवस्था हुन आवश्यक छ। <br>
त्यसैले MiDas eCLASS ले Web र App बाट निम्न सेवा र सुबिधा उपलब्ध गराएको छ।<br>

✓ MiDas eCLASS मा मुख्य विषयका पाठहरुको Concept बुझाउने Animated Video Lesson हरू राखिएको छ। यि Video Lesson हरूले विध्यार्थीहरुको पढाइमा रूची बढाउनुको साथै अप्ठेरा पाठहरु सजिलै बुझ्न मद्दत गर्छ। यसले गर्दा उनिहरूको सिकाइ दिर्घकालीन हुन्छ । <br>

✓ साना नानीबाबुहरूको लागि Cartoon Character प्रयोग गरेर रमाइला Video Lesson हरू तयार पारिएको छ। जसले गर्दा उनीहरू Cartoon Film हेरेजस्तै रमाउँदै हेरेर आफ्नो पाठ सजिलै सिक्छन्। <br>

✓ पढेको कुर नबुझेमा, Homework गर्न नजानेमा वा पढाइको बारेमा कुनै जिज्ञासा भएमा विध्यार्थीहरुले जहाँबाट जतिबेला पनि MiDas eCLASS मा सोध्न सक्छन्। हरेक विषयका सयौं शिक्षकहरू बेलुका ५ बजे देखि ९ बजे सम्म MiDas eCLASS मा Online हुनुहुन्छ। उहाँहरूले विद्यार्थीहरूलाई Tuition Teacher ले घरमै सिकाए जस्तै गरि हरेक प्रश्नको उत्तर तुरुन्त दिनुहुन्छ। <br>

✓ बाबु आमाले पनि आफ्नो बच्चालाई सिकाउन खोज्दा नजानेको कुरा MiDas eCLASS मा सोधेर पहिले आफुले सिकेर आफ्नो बच्चालाई सिकाउन सक्नुहुन्छ। <br>

✓ MiDas eCLASS मा विषयविज्ञ शिक्षकहरूले पाठमा आधारित प्रश्नहरूको उत्तर दिने तरिका र Mathematical Problems Solve गर्ने तरिका सिकाएको Tutorial Video राखिएको छ, जसलाई विद्यार्थीहरूले जहाँबाट जतिबेला पनि हेरेर सिक्न सक्छन्। <br>

✓ MiDas eCLASS मा पाठामा आधारित हजारौं Quizzes & Games राखिएको छ। ति Quizzes & Games रमाउदै खेलेर पनि विध्यार्थीहरुले आफ्नो पाठ सजिलै सिक्छन्। साथै यि पाठामा आधारित Quizzes र Game हरूले विध्यार्थीहरुको सिकाइमा रूची पनि बढाउछ। <br>

✓ साना नानीबाबुहरूले त आफ्नो पुरै पाठ Quizzes & Games खेलेर नै सिक्न सक्छन्। <br>

✓ विद्यार्थीहरूलाई परीक्षाको तयारी गर्न मद्दत गर्न हरेक विषयको नमुना प्रश्न र उत्तर MiDas eCLASS मा राखिएको छ। विद्यार्थीहरूले आफूले चाहेको विषयको कुनै पनि पाठ छानेर नमुना परीक्षा दिन सक्छन् र आफ्नो उत्तरलाई त्यहाँ दिइएको उत्तरसँग दाँज्न सक्छन्। <br>

✓ अभिभावकहरूले पनि MiDas eCLASS बाट प्रश्नपत्र निकालेर आफ्नो बच्चालाई नमुना परीक्षा गराउन सक्नुहुन्छ। बच्चाले दिएको उत्तर त्यहीँ दिइएको उत्तरसँग दाँजेर हेर्न सक्नुहुन्छ। <br>

✓ MiDas eCLASS मा हजारौँ स्कूलका विद्यार्थीहरूले प्रश्नहरू सोधिरहेका हुन्छन्। सयौँ शिक्षकहरुले उत्तर दिइरहनुभएको हुन्छ। हजारौँ विद्यार्थीहरू छलफलमा सहभागी भइरहेका हुन्छन् । यसले हरेक विद्यार्थीहरूलाई अरू हजारौँ स्कूलका विद्यार्थीहरू र शिक्षकहरू माझ पुर्याउँछ। उनीहरुको सोचाइ र बुझाइलाई फराकिलो बनाउँछ। उनीहरूको आत्मविश्वास बढ्छ, उनीहरू बढी प्रतिस्पर्धी हुन्छन्, योग्य हुन्छन् । <br>

-------------------------------------------------------------<br>
MiDas eCLASS ले विद्यार्थीहरुको पढाइमा सुधार कसरी ल्याउछ थाहा पाउन www.midaseclass.com मा आजै Log In गर्नुहोस वा Google Play बाट MiDas eCLASS App Install गर्नुहोस। <br>
यसको लागि पैसा लाग्दैन।<br>

यदि तपाईलाई मन पर्यो भने पैसा तिरेर MiDas eCLASS बाट आफ्नो बच्चालाई सिक्न दिनुहोस्। <br>

IME Pay, eSEWA, Master Card वा Visa Card बाट MiDas eCLASS को लागि पैसा तिर्न सकिन्छ। <br>

नजिकैको IME Counter, eSEWA Zone वा पुस्तक, स्टेसनरि तथा मोबाइल पसलहरूमा गएर पनि पैसा तिर्न सकिन्छ। 
साथै देश भरिको कुनै पनि बैंकबाट पनि पैसा तिर्न सकिन्छ। <br>

मुख्य शहरहरूमा Cash On Delivery (CoD) को पनि ब्यवस्था छ।<br>

==============================================<br>
थप जानकारिको लागि:<br>
Ph: 9851228009, 9851170896, 01- 4244461
		  
		  
		  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>        
      </div>
    </div>
  </div>
</div>

<!-- MiDas App- For Teacher Modal -->
<div class="modal fade" id="app4teacher" tabindex="-1" role="dialog" aria-labelledby="MiDas" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle"><strong>MiDas App </strong>- For Teacher</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
		
      </div>
		
      <div class="modal-body">
        <div class="m-desc">
		ONLY TEACHERS & MANAGEMENT TEAM OF A SCHOOL SHOULD DOWNLOAD THIS APP. <br><br>
With this App, Teachers can <br>
- Manage School Calendar<br>
- Take Attendance<br>
- Assign Homework<br>
- Evaluate / Monitor Homework<br>
- Manage Marks<br>
- Send Personal / Group Messages to Parents, Students and Teachers<br>
		  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>        
      </div>
    </div>
  </div>
</div>


<!-- Livestock Farming (पशुपालन) Modal -->
<div class="modal fade" id="livestock" tabindex="-1" role="dialog" aria-labelledby="MiDas" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle"><strong>Livestock Farming (पशुपालन)</strong></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
		
      </div>
		
      <div class="modal-body">
        <div class="m-desc">
			<div>
		<h2>What is Lorem Ipsum?</h2>
		<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
		</div>
		  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>        
      </div>
    </div>
  </div>
</div>